const debug = (): void => {
  // eslint-disable-next-line no-debugger
  debugger;
};

const pass = (): void => {};

export {
  debug,
  pass
};
